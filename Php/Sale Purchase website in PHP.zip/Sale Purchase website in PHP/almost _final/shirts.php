<!Doctype html>
  <html>
	<head>
		<link rel="stylesheet" href="levis3.css"/>
		
		
		<script type="text/javascript">
			
				
				function img(id) 
					{
					document.getElementById('nw').src = "jacket/"+id+".jpg";
					}
			
		
		</script>
			
		
	</head>
	
	<body>
	 <div  id="total">
	  <div id="back">
			<img src="ghq.jpg"id="img1"/>
			<div id = "Menu">
			<ul id="list">
						<a href="home levis.php"><li>Home</li></a>
						<a href="items.php"><li>Items</li></a>
						<a href="shirts.php"><li>Shirts</li></a>
						<a href="jeans.php"><li>Jeans</li></a>
						<a href="form1.php"><li>form</li></a>
						<a href="read.php"><li>viewdata</li></a>
						<a href="contact.php""><li>contact us</li></a>
					</ul>
			</div>
			<img src="stunt.jpg" id="img2"/>
	  </div>
	 <br>	  
	  <div id="center">
			<h1>
				Shirts
			</h1>
			<div id="gallery">
				<img src="jacket/1.jpg" id="1"  onmouseover="img(1);" />
				<img src="jacket/2.jpg" id="2"  onmouseover="img(2);" />
				<img src="jacket/3.jpg" id="3"   onmouseover="img(3);"/>
				<img src="jacket/4.jpg" id="4"  onmouseover="img(4);" />
				<img src="jacket/5.jpg" id="5" onmouseover="img(5);" />
				<img src="jacket/6.jpg" id="6"  onmouseover="img(6);" />
				<img src="jacket/7.jpg" id="7"  onmouseover="img(7);" />
				<img src="jacket/8.jpg" id="8"   onmouseover="img(8);"/>
				<img src="jacket/9.jpg" id="9"  onmouseover="img(9);" />
				<img src="jacket/10.jpg" id="10" onmouseover="img(10);" />
				<img src="jacket/11.jpg" id="11"  onmouseover="img(11);" />
				<img src="jacket/12.jpg" id="12"  onmouseover="img(12);" />
				<img src="jacket/13.jpg" id="13"   onmouseover="img(13);"/>
				<img src="jacket/14.jpg" id="14"  onmouseover="img(14);" />
				<img src="jacket/15.jpg" id="15" onmouseover="img(15);" />
				
			</div>
			
			<div id="bigpic">
				<img src="jacket/1.jpg" id="nw" />
			<div>
		
			<a href="form1.php">
				<img src="purchase.png" id="purchase"/>
			</a>
			
	  <br><br><br>
	  
	  <div id="right">
		
		
		
	  </div>
		
			<div id="footer" >
					<p>
						All Rights Reserved
					</p>
		    </div>
			
	  
	 </div>
	</div>
	  
	</body>  
	  