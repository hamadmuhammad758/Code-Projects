<!Doctype html>
  <html>   <head>
                  
            <link rel="stylesheet" href="levis5.css">
            
        <script type="text/javascript">
							function validnumb(id)
							{
							var check=document.getElementById(id).value;
					
									if(check=="")
											{
										
											document.getElementById(id).style.backgroundColor="pink";
											document.getElementById("s"+id).innerHTML=" * Value Required";
									
											}
									else
													
											{
											var b=document.getElementById(id).value;
											b=parseInt(b);
											if(isNaN(b))
													{
													document.getElementById(id).style.backgroundColor="pink";
													document.getElementById("s"+id).innerHTML=" * Not a Number";
													}
											}								
							}
						function valid(id)
								{
								var check=document.getElementById(id).value;
					
									if(check=="")
											{
										
											document.getElementById(id).style.backgroundColor="pink";
											document.getElementById("s"+id).innerHTML=" * Value Required";
									
											}
										else
											{
											document.getElementById("s"+id).innerHTML="";
											document.getElementById(id).style.backgroundColor="#fff";
											}

								}

		</script>
	<head>
	
	<body>
	 <div  id="total">
		<div id="back">
			<img src="ghq.jpg"id="img1"/>
			<div id = "Menu">
					<ul id="list">
						<a href="home levis.php"><li>Home</li></a>
						<a href="items.php"><li>Items</li></a>
						<a href="shirts.php"><li>Shirts</li></a>
						<a href="jeans.php"><li>Jeans</li></a>
						<a href="form1.php"><li>form</li></a>
						<a href="read.php"><li>viewdata</li></a>
						<a href="contact.php"><li>contact us</li></a>
					</ul>
			</div>
			<img src="stunt.jpg" id="img2"/>
	    </div>
			<br>

			
		<div id="center">
			<div id="form">
				<form action="add1.php" method="get">
					<br>
					<h1  id="heading">
						Fill to buy
					</h1>
					
					<table class="form-table">	
						<tr>
							<td ><label for="1">CUSTOMER NAME:</label></td>
							<td ><input type="text" name="customername" id="1"   onblur="valid(1);"  /></td>
							<td cl	ass="error"><span id="s1"></td>
						
						</tr>
						
						<tr>
							<td ><label for="2">PRODUCT NAME:</label></td>
							<td ><input type="text" name="productname" id="2"   onblur="valid(2);"  /></td>
							<td  ><span id="s2"></td>
						</tr>
												
						<tr>
							<td ><label for="3">Price</label></td>
							<td ><input type="number" name="price" id="3"    onblur="validnumb(3);"  ></td>
							<td  ><span id="s3"></td>

						</tr>
						
						<tr>
							<td ><label for="4">Phone No </label></td>
							<td ><input type="number" name="phone" id="4"   onblur="validnumb(4);" ></td>
							<td  ><span id="s4"></td>
						</tr>
						
						<tr>
							<td ><label for="5">Email Address</label></td>
							<td ><input type="email" name="email" id="5"   onblur="valid(5);" ></td>
							<td  ><span id="S5"></td>
						</tr>
	
						<tr>
							<td ><label for="Ship Province">Country</label></td>
							<td ><input type="text" name="country" id="6"   onblur="valid(6);" ></td>
							<td  ><span id="s6"></td>
						</tr>
						
						<tr>
							<td ><label for="Ship Postal Code">Ship Postal Code</label></td>
							<td ><input type="text" name="address" id="7"   onblur="valid(7)" ></td>
							<td  ><span id="s7"></td>
						</tr>
						
					
							
					<tr>
							<td></td>
							<td >
							<input type="submit" value="SAVE YOUR DATA" class="btn"/>
							<input type="reset" value="Reset" class="btn"/></td>
							<td></td>
						</tr>
					
					</table>
					
				</form>
			</div>
	  </div>
	  <br><br><br>
	  
	  <div id="right">
	
		
	  </div>
		
			<div id="footer" >
					<p>
						All Rights Reserved
					</p>
		    </div>
			
	  
	 </div>
	</div>
	  
	</body>  
	  