<!Doctype html>
  <html>
	<head>
		<link rel="stylesheet" href="levis1.css"/>
		
		
		<script type="text/javascript">
			var b=new Array();
				i=0;
				var c;
				function pic()
				{	
				
					if(i==10)
					
					i=0;
					
					document.getElementById('1').src="jacket/"+i+".jpg";
					document.getElementById('2').src="shorts/"+i+".jpg";
					document.getElementById('3').src="belts/"+i+".jpg";
					document.getElementById('4').src="pent/"+i+".jpg";
					i+=1;
					
					c=setTimeout('pic();',500);
				}
				
				function stop()
				{
					clearTimeout(c);
				}
			
			</script>
			
		
	</head>
	
	<body>
	 <div  id="total">
	  <div id="back">
			<img src="ghq.jpg"id="img1"/>
			<div id = "Menu">
				<ul id="list">
						<a href="home levis.php"><li>Home</li></a>
						<a href="items.php"><li>Items</li></a>
						<a href="shirts.php"><li>Shirts</li></a>
						<a href="jeans.php"><li>Jeans</li></a>
						<a href="form1.php"><li>form</li></a>
						<a href="read.php"><li>viewdata</li></a>
						<a href="contact.php"><li>contact us</li></a>
					</ul>
			</div>
			<img src="stunt.jpg" id="img2"/>
	  </div>
	 <br>	  
	  <div id="center">
			<h1>
				We Provide The Best...
			</h1>
	  
			<p>
			    Created in 1873, Levi's® jeans are the original, authentic jeans.
				They are the most sucessful, widely recognised and often imitated
				clothing products in the history of apparel.Over successive generations,
				Levi's® jeans have captured the attention, imagination and loyalty 
				of diverse individuals.As the inventor of the category, the Levi's® brand 
				continues to define jeanswear with the widest range of products available,
				from quitessential classics such as the famous Levi's® 501® Orginal jean,
				to favorite fits and styles in the Red Tab™ and premium collections
			</p>
			
			  
	  </div>
	  <br><br><br>
	  
	  <div id="right">
		
		<a href="shirts.php"><img src="jacket/1.jpg" id="1"    onmouseout="pic();" onmouseover="stop();"/>	</a>	
		 <a href="jeans.php"><img src="shorts/1.jpg" id="2"    onmouseout="pic();" onmouseover="stop();"/></a>
		 <a href="jeans.php"> <img src="belts/1.jpg" id="3"    onmouseout="pic();" onmouseover="stop();"/></a>
		 <a href="jeans.php"> <img src="pent/1.jpg" id="4"    onmouseout="pic();" onmouseover="stop();"/></a>
		
		
		<script type="text/javascript" >
			c=setTimeout('pic();',500);
		</script>
		
	  </div>
		
			<div id="footer" >
					<p>
						All Rights Reserved
					</p>
		    </div>
			
	  
	 </div>
	</div>
	  
	</body>  
	  <?php
          
          echo("usmna");
          ?>