<!DOCTYPE html>
<html>
	<head>
	</head>
	<body>
				<?php
							$name=$_GET['customername'];
							$product=$_GET['productname'];
							$mail=$_GET['email'];
							$price=$_GET['price'];
							$phone=$_GET['phone'];
							$country=$_GET['country'];
							$add=$_GET['address'];
							
							$old=file_get_contents("data.txt");
						
							$new[0]=$name;
							$new[1]=$product;
							$new[2]=$mail;
							$new[3]=$price;
							$new[4]=$phone;
							$new[5]=$country;
							$new[6]=$add;
							
							$new=implode($new , "##"); 
						
							file_put_contents("data.txt",$new."\n".$old);
							header("Location:home levis.php");
					?>
	</body>
</html>