<!Doctype html>
  <html>
	<head>
		<link rel="stylesheet" href="levis3.css"/>
		
		
		<script type="text/javascript">
	
				function img(id) 
					{
					document.getElementById('nw').src = "pent/"+id+".jpg";
					}
			
		
		</script>
			
		
	</head>
	
	<body>
	 <div  id="total">
	  <div id="back">
			<img src="ghq.jpg"id="img1"/>
			<div id = "Menu">
				<ul id="list">
						<a href="home levis.php"><li>Home</li></a>
						<a href="items.php"><li>Items</li></a>
						<a href="shirts.php"><li>Shirts</li></a>
						<a href="jeans.php"><li>Jeans</li></a>
						<a href="form1.php"><li>form</li></a>
						<a href="read.php"><li>viewdata</li></a>
						<a href="contact.php"><li>contact us</li></a>
					</ul>
			</div>
			<img src="stunt.jpg" id="img2"/>
	  </div>
	 <br>	  
	  <div id="center">
			<h1>
				Jeans
			</h1>
			<div id="gallery">
				<img src="pent/1.jpg" id="1"  onmouseover="img(1);" />
				<img src="pent/2.jpg" id="2"  onmouseover="img(2);" />
				<img src="pent/3.jpg" id="3"   onmouseover="img(3);"/>
				<img src="pent/4.jpg" id="4"  onmouseover="img(4);" />
				<img src="pent/5.jpg" id="5" onmouseover="img(5);" />
				<img src="pent/6.jpg" id="6"  onmouseover="img(6);" />
				<img src="pent/7.jpg" id="7"  onmouseover="img(7);" />
				<img src="pent/8.jpg" id="8"   onmouseover="img(8);"/>
				<img src="pent/9.jpg" id="9"  onmouseover="img(9);" />
				<img src="pent/10.jpg" id="10" onmouseover="img(10);" />
				<img src="pent/11.jpg" id="11"  onmouseover="img(11);" />
				<img src="pent/12.jpg" id="12"  onmouseover="img(12);" />
				<img src="pent/13.jpg" id="13"   onmouseover="img(13);"/>
				<img src="pent/14.jpg" id="14"  onmouseover="img(14);" />
				<img src="pent/15.jpg" id="15" onmouseover="img(15);" />
				
			</div>
			
			<div id="bigpic">
				<img src="pent/1.jpg" id="nw" />
			<div>
			
			<a href="form1.php">
				<img src="purchase.png" id="purchase"/>
			</a>
			
	  </div>
	  <br><br><br>
	  
	  <div id="right">
		
		
		
	  </div>
		
			<div id="footer" >
					<p>
						All Rights Reserved
					</p>
		    </div>
			
	  
	 </div>
	</div>
	<?php
		?>
	</body>  
	  