<!DOCTYPE html>
<html>
	<head>
		
		<link rel="stylesheet" href="levis1.css"/>
		<style type="text/css">
			#tbl{
				border:1px solid black;
				margin-top:50px;
				border-collapse:collapse;
			}
			#tbl td{
				border:1px solid black;
				padding:5px;
			}
			h1{
				text-align:center;
			}
			#center{
				
				color:cyan;
				min-height:570px;
				min-width:1382px;
				padding:54px;
			}
			#footer{
				position:relative;
				bottom:5px;
			}
		</style>
	</head>
	<body>
		<body>
	 <div  id="total">
	  <div id="back">
			<img src="ghq.jpg"id="img1"/>
			<div id = "Menu">
				<ul id="list">
						<a href="home levis.php"><li>Home</li></a>
						<a href="items.php"><li>Items</li></a>
						<a href="shirts.php"><li>Shirts</li></a>
						<a href="jeans.php"><li>Jeans</li></a>
						<a href="form1.php"><li>form</li></a>
						<a href="read.php"><li>viewdata</li></a>
						<a href="contact.php"><li>contact us</li></a>
					</ul>
			</div>
			<img src="stunt.jpg" id="img2"/>
	  </div>
	 <br>	  
	  <div id="center">
		<h1>
			Reocrds who bought Our product
		</h1>
		<?php
			 $file=file_get_contents("data.txt");
			
			 if($file="")
			 echo("no data is there");
			 else{
				echo("<center>");
				echo("<table id='tbl'>");
				echo("<tr><th>Sr.No</th>");
				echo("<th>Name</th>");
				echo("<th>productname</th>");
                echo("<th>email</th>");
                echo("<th>price</th>");
                echo("<th>phone</th>");
                echo("<th>country</th>");
                echo("<th>address</th>");
                echo("</tr>");
				
                               
                $file=file_get_contents("data.txt");			
				$data=explode("\n" , $file);
				
				$flag=0;
				for($i=0 ; $i<count($data) ; $i++)
				{	
					$new=explode("##" ,$data[$i]);
					$flag++;
					if(isset($new[1]))
					{
					
					echo("<tr><td>".$i."</td>");
					echo("<td>"  .$new[0]. "</td>");
                    
					echo("<td>"  .$new[1]."</td>");
                    echo("<td>"  .$new[2]. "</td>");
                    echo("<td>"  .$new[3]. "</td>");
                    echo("<td>"  .$new[4]. "</td>");
                    echo("<td>"  .$new[5]. "</td>");
					echo("<td>"  .$new[6]. "</td>");
					}
					echo("</tr>");
					
				}	
if($flag==1)
{
	$flag=0;
	echo"No Record Found";
}				
					echo("</table>");
					echo("</center>");
				}
		?>   
			</div>
				
	  </div>
		
			<div id="footer" >
					<p>
						All Rights Reserved
					</p>
		    </div>
			
	  
	 </div>
		</div>
	</body>
</html>
