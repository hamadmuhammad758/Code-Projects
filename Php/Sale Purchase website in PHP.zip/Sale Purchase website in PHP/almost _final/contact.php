<!Doctype html>
  <html>
	<head>
		<link rel="stylesheet" href="levis6.css"/>
		
		
		<script type="text/javascript">
			var b=new Array();
				i=0;
				var c;
				function pic()
				{	
				
					if(i==10)
					
					i=0;
					
					document.getElementById('1').src="jacket/"+i+".jpg";
					document.getElementById('2').src="shorts/"+i+".jpg";
					document.getElementById('3').src="belts/"+i+".jpg";
					document.getElementById('4').src="pent/"+i+".jpg";
					i+=1;
					
					c=setTimeout('pic();',500);
				}
				
				function stop()
				{
					clearTimeout(c);
				}
			
			</script>
			
		
	</head>
	
	<body>
	 <div  id="total">
	  <div id="back">
			<img src="ghq.jpg"id="img1"/>
			<div id = "Menu">
				<ul id="list">
						<a href="home levis.php"><li>Home</li></a>
						<a href="items.php"><li>Items</li></a>
						<a href="shirts.php"><li>Shirts</li></a>
						<a href="jeans.php"><li>Jeans</li></a>
						<a href="form1.php"><li>form</li></a>
						<a href="read.php"><li>viewdata</li></a>
						<a href="contact.php"><li>contact us</li></a>
					</ul>
			</div>
			<img src="stunt.jpg" id="img2"/>
	  </div>
	 <br>	  
		<div id="center">
			<h1>
				About us
				
			</h1>
	  
			<p>
				Dr.  Martin Levis <br>
				46B/harley uk<br>
				LEVIS@ymail.com
			</p>
			  
		</div>
		
		<div id="footer" >
					<p>
						All Rights Reserved		
					</p>
		</div>
	</div>
	  
	</body>  
</html>
	  <?php
          
          echo("usman");
          ?>