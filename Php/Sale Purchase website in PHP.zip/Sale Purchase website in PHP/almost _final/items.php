<!Doctype html>
  <html>
	<head>
		<link rel="stylesheet" href="levis2.css"/>
		
		
		<script type="text/javascript">
			var b=new Array();
				i=0;
				var c;
				function pic()
				{	
				
					if(i==20)
					
					i=0;
					
					document.getElementById('jacket').src="jacket/"+i+".jpg";
					document.getElementById('pent').src="pent/"+i+".jpg";
					document.getElementById('belts').src="belts/"+i+".jpg";
					document.getElementById('kids').src="kids/"+i+".jpg";
					document.getElementById('shorts').src="shorts/"+i+".jpg";
					document.getElementById('jackets').src="jackets/"+i+".jpg";
					i+=1;
					c=setTimeout('pic();',500);
				}
				
				function stop()
				{
					clearTimeout(c);
				}
			
			</script>
			
		
	</head>
	
	<body>
	 <div  id="total">
		<div id="back">
			<img src="ghq.jpg"id="img1"/>
			<div id = "Menu">
				<ul id="list">
						<a href="home levis.php"><li>Home</li></a>
						<a href="items.php"><li>Items</li></a>
						<a href="shirts.php"><li>Shirts</li></a>
						<a href="jeans.php"><li>Jeans</li></a>
						<a href="form1.php"><li>form</li></a>
						<a href="read.php"><li>viewdata</li></a>
						<a href="contact.php"><li>contact us</li></a>
					</ul>
			</div>
			<img src="stunt.jpg" id="img2"/>
	  </div>
	 <br>	  
	  <div id="center">
			<br><br>
			<img src="misc/essential.jpg" id="essential" />
				
		<img src="sale.gif" id="img5"  />
			<br><br>  
	  </div>
	  <br><br><br>
	  
	  <div id="right">
		
		<img src="jacket/1.jpg" id="jacket"    onmouseout="pic();" onmouseover="stop();"/>		
		<img src="pent/1.jpg" id="pent"    onmouseout="pic();" onmouseover="stop();"/>		
		<br><img src="shorts/1.jpg" id="shorts"    onmouseout="pic();" onmouseover="stop();"/>		
		<img src="belts/1.jpg" id="belts"    onmouseout="pic();" onmouseover="stop();"/>
		<br><img src="kids/1.jpg" id="kids"    onmouseout="pic();" onmouseover="stop();"/>
		<img src="jackets/1.jpg" id="jackets"    onmouseout="pic();" onmouseover="stop();"/>
	
		
		
		<script type="text/javascript" >
			c=setTimeout('pic();',50);
		</script>
				<p id="pa">
					Jeans are trousers made from denim or dungaree cloth. 
					Often the term "jeans" refers to a particular style 
					of trousers, called "blue jeans" and invented by 
					Jacob Davis and Levi Strauss in 1873. Starting in the
					1950s, jeans, originally designed for cowboys, became
					popular among teenagers, especially members of the 
					greaser subculture. Historic brands include Levi's, 
					Lee, and Wrangler. Jeans come in various fits, including 
					skinny, tapered, slim, straight, boot cut, Narrow bottom,
					Low waist, anti-fit and flare.
				</p>
		 </div>
		
			
			<div id="footer" >
					<p>
						All Rights Reserved
					</p>
		    </div>
	  
	 </div>
	</div>
	<?php
			?>	
	</body>  
	  