<?php   ?>
<html>
	<body>

	  <div id="back">
			<img src="ghq.jpg"id="img1"/>
			<div id = "Menu">
					<ul id="list">
						<li>Home</li>
						<li>Items</li>
						<li>Shirts</li>
						<li>Jeans</li>
						<li>form</li>
						<li>contact us</li>
					</ul>
			</div>
			<img src="stunt.jpg" id="img2"/>
	  </div>
	</body>
</html>	  