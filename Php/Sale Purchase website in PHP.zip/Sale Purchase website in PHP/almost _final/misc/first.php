<!DOCTYPE html>
<html>
	<head>
		
	</head>
	
	<body>
	  <?php
		&num=22;
		var_dump($num);
	  ?>
	</body>
</html>