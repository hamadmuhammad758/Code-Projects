<?php
				
				include 'open_connection_with_db.php';
                $q = $_GET['q'];
                $ret_id=$_GET['ret_id'];

                if($q=="addCategory"){
                	echo '
		                <h2 style="text-align:center;" id="addnewCategory" >Add new Category</h2>
		          
		                <div class="form-group col col-sm-4 col-sm-offset-4 " >
		                    <form   class=""  action=""   method="post" >
		                      <div class="form-group">
		                        <input type="" class="form-control"  name="newCat"  required id="txt_cat"  value="" placeholder="Create new Category">
		                      </div>
		                        <button type="submit" name="submit" class="btn btn-default">Add</button>             
		                    </form>
		                 </div>';
                }
                else if($q=="deleteCategory"){
	
                    $sQuery="SELECT name FROM category where retailer_id='$ret_id'";

                    $r=mysqli_query($connection,$sQuery);

                    $res="";
                    if (mysqli_num_rows($r) > 0) {
                        while($ro = mysqli_fetch_assoc($r)) {
                            $res=$res."<option>".$ro["name"]."</option>";
                        }
                    }


     				echo '
		                <div class="form-group col col-sm-4 col-sm-offset-4 " ><form   class=""  method="post" >
                     <h2 style="text-align:center;" id="deleteCategory" >Delete Category</h2>
                        <div class="form-group">
                            <select name="cats" class="form-control">'.$res.'
                            </select>

                        </div>
                            <button type="submit" name="submit" class="btn btn-default">Delete</button>                
                    </form></div>';
                    
                }
                else if($q=="addSubcategory"){
    
                    $sQuery="SELECT name FROM category where retailer_id='$ret_id'";

                    $r=mysqli_query($connection,$sQuery);
                    $res="";
                    if (mysqli_num_rows($r) > 0) {
                        while($ro = mysqli_fetch_assoc($r)) {
                           $res=$res."<option>".$ro["name"]."</option>";
                        }
                    }
     				echo '
		                <div class="form-group col col-sm-4 col-sm-offset-4 " >
               			 <h2 style="text-align:center;" id="addnewSubcategory" >Add new Subcategory</h2>
	                    <form   class="" method="post" >
	                      <div class="form-group">
	                          <select name="sscats" class="form-control">'.$res.'</select>

	                      </div>

	                      <div class="form-group">
	                        <input type="" class="form-control"  name="newSubCat"  required id="txt_cat"  value="">
	                      </div>
	                      
	                      <div class="form-group">

	                      </div>

	                        <button type="submit" name="submit" class="btn btn-default">Add</button>

	                
	                    </form></div>';
                }
                else if($q=="deleteSubcategory"){


                    $sQuery="SELECT name FROM category where retailer_id='$ret_id'";

                    $r=mysqli_query($connection,$sQuery);

                    $res="";
                    if (mysqli_num_rows($r) > 0) {
                        while($ro = mysqli_fetch_assoc($r)) {
                            $res=$res."<option>".$ro["name"]."</option>";
                        }
                    }
                     echo '
		                <div class="form-group col col-sm-4 col-sm-offset-4 " >
	                	 <form   class="" method="post" >
	                     <h2 style="text-align:center;" id="deleteSubcategory" >Delete Subcategory</h2>
		                    <div class="form-group">
		                            <select name="ccats" class="form-control"  onchange="getCategories(\'showForDelete\',this.value)">
		                            	'.$res.'
		                            </select>

		                    </div>


	                    <div class="form-group">
	                          <select name="subscats" id="showForDelete" class="form-control">
	                            
	                        </select>

	                      </div>
	                            <button type="submit" name="submit" class="btn btn-default">Delete</button>                
	                    </form>  </div>';
                }
                else if($q=="viewCategory"){
                	
                }
                else if($q=="addProduct"){
	
                    $sQuery="SELECT name FROM category where retailer_id='$ret_id'";

                    $r=mysqli_query($connection,$sQuery);

                    $res="";
                    if (mysqli_num_rows($r) > 0) {
                        while($ro = mysqli_fetch_assoc($r)) {
                            $res=$res."<option>".$ro["name"]."</option>";
                        }
                    }

                     echo '
		                <div class="form-group col col-sm-4 col-sm-offset-4 " >
                    <form   class="" method="post"  enctype="multipart/form-data" >
                     <h2 style="text-align:center;" id="new_product">Add New Product</h2>
                        <div class="form-group">
                            <select name="catsForNewProducts" class="form-control"  onchange="getCategories(\'insideSubcatAj\',this.value)">
							'.$res.'
							</select>

                        </div>
                        
                        <div class="form-group">
                          <select name="subscatsForNewProducts" id="insideSubcatAj" class="form-control">

                          </select>

                        </div> 
                                
                      <div class="form-group">
                        <input type="text" class="form-control"  name="pro_name"  required id=""  placeholder="Name">
                      </div>

                      <div class="form-group">
                        <input type="Number" class="form-control"  name="pro_price"  required id=""   placeholder="Price">
                      </div>

                      <div class="form-group">
                        <input type="text" class="form-control"  name="pro_unit"  required id=""   placeholder="Unit of Product">
                      </div>

                      <div class="form-group">
                        <input type="Number" class="form-control"  name="pro_stock"  required id=""   placeholder="Stock">
                      </div>

                      <div class="form-group">
                        <textarea name="pro_description"  rows="5" cols="58" placeholder="Product Description" >
                        </textarea> 
                      </div>
                            <input type="file"  class="btn btn-default" name="fileToUpload" id="fileToUpload">
          
                            <button type="submit" name="submit" class="btn btn-default">Add</button>                
                    </form> 

                </div>';
                }
                else if($q=="editProduct"){
	
                        $sQuery="SELECT name FROM category where retailer_id='$ret_id'";

                        $r=mysqli_query($connection,$sQuery);
                        $res="";

                        if (mysqli_num_rows($r) > 0) {
                            while($ro = mysqli_fetch_assoc($r)) {
                                $res=$res."<option>".$ro["name"]."</option>";
                            }
                        }
                        echo '
                	   <div  class="form-group col col-sm-4 col-sm-offset-4 " >
                        <form   class="" method="post"  enctype="multipart/form-data" >
                             <h2 style="text-align:center;" id="edit_product" >Edit/Delete Product</h2>
                                <div class="form-group">
                                    <select name="catsFordeleteProducts" class="form-control"  onclick="getCategories(\'insideSubcatForDeleteAj\',this.value)">
                                       '.$res.'
                                    </select>

                                </div>
                                
                                <div class="form-group">
                                  <select name="subscatsForDeleteProducts" id="insideSubcatForDeleteAj" class="form-control"   onchange="showUser4(this.value)">
                                  </select>
                                </div> 


                                <div class="form-group">
                                  <select name="ProductsToDeleteProducts" id="insideProductDeleteAj" class="form-control" onchange="showProductsDetails(this.value)" >
                                  </select>
                                </div> 

        

                                  <div class="form-group">
                                    <input type="Number" class="form-control"  name="update_pro_price"  required id="update_pro_price"   placeholder="Price">
                                  </div>

                                  <div class="form-group">
                                    <input type="text" class="form-control"  name="update_pro_unit"  required id="update_pro_unit"   placeholder="Unit of Product">
                                  </div>

                                  <div class="form-group">
                                    <input type="Number" class="form-control"  name="update_pro_stock"  required id="update_pro_stock"   placeholder="Stock">
                                  </div>

                                  <div class="form-group">
                                    <textarea name="update_pro_description" id="update_pro_description" rows="5" cols="58" placeholder="Product Description" >
                                    </textarea> 
                                  </div>
                         
                                <button type="submit" name="EditProduct" id="toggleEdit" class="btn btn-default">Update</button>
                                <button type="submit" name="DeleteProduct" class="btn btn-default">Delete</button>     
                        </form>
                          
                </div>';
                }
                else if($q=="editCategories"){
                  $sQuery="SELECT name FROM category where retailer_id='$ret_id'";
                  $res="";
                  $r=mysqli_query($connection,$sQuery);
                  if (mysqli_num_rows($r) > 0) {
                      while($ro = mysqli_fetch_assoc($r)) {
                          $res=$res."<option>".$ro["name"]."</option>";
                      }
                  }
                  echo'
                  <div  class="form-group col col-sm-4 col-sm-offset-4 " >

                        <form   class="" method="post"  enctype="multipart/form-data" >
                             <h2 style="text-align:center;" id="edit_product" >Edit Categories/Subcategories</h2>
                                <div class="form-group">
                                    <select name="editcatsSubcats" class="form-control" onchange="getCategories(\'insideeditSubcatscats\',this.value)">
                                        '.$res.'
                                    </select>

                                </div>
                                <div class="form-group">
                                  <select name="editSubcatscats" id="insideeditSubcatscats" class="form-control" onchange="editCatVal(this.value)" >
                                  </select>
                                </div> 
                                <div class="form-group">
                                    <input type="text" class="form-control" id="id_editedCategory" name="name_editedCategory" placeholder="Edit Category name">
                                </div>
                                <div class="form-group">
                                    <input type="text" class="form-control" id="id_editedSubcategory" name="name_editedSubcategory" placeholder="Edit Subcategory name">
                                </div>
                                <input type="submit" name="update_cat" class="btn btn-default" value="Update Category" /> 
                                <input type="submit" name="update_subcat" class="btn btn-default"  value="Update Subategory" /> 
                        </form>
                </div>';
                }
?>