<?php
	include 'open_connection_with_db.php';
	$pro=$_GET["prod"];
	$ins="SELECT * FROM comment WHERE product_id='$pro'";
	$ans="";
	$r=mysqli_query($connection,$ins);
	$roww=mysqli_num_rows($r);
	if(mysqli_num_rows($r)>0){
		while ($res=mysqli_fetch_assoc($r)){
			//$ans=$ans.$res[]
				if($roww<10){
					$ans=$ans.'<div style="border-bottom:3px solid #333;margin-top:8px;">
						<h3 style="display:inline-block;">'.$res["name"].'</h3>
						<p style="display:inline-block;">'.$res["date_time"].'</p>
						<p style="display:block;">'.$res["description"].'</p>
						</div>';}	
				$roww--;
		}
	}
	echo''.$ans;
?>