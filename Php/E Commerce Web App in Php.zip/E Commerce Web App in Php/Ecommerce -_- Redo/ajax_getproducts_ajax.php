<?php

                $connection = new mysqli("localhost", "root","","shopper");
                
                if ($connection->connect_error) 
                    die("Connection failed with database");

                $q = $_GET['q'];
                $ret_id=$_GET['ret_id'];

                $selecSubcat="SELECT product.name FROM product,subcategory,category
                              WHERE category.retailer_id='$ret_id' AND category.cat_id=subcategory.cat_id 
                              AND subcategory.subcat_id=product.subcat_id AND  subcategory.name='$q'";

                 $r=mysqli_query($connection,$selecSubcat);

                 $returning_value="";
                                    if (mysqli_num_rows($r) > 0) {
                                        while($ro = mysqli_fetch_assoc($r)) {
                                            $returning_value=$returning_value."<option>".$ro["name"]."</option>";
                                        }
                                    }

                            echo "".$returning_value;
?>