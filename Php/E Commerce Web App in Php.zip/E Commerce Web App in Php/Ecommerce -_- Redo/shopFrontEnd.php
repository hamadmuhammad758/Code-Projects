<!doctype html><!---->
<html>
<head>
    <?php 
        session_start(); 
        include 'main_Menu_after_Login.php';
            
            
            if(isset($_SESSION["validUser"]))
                {
                    if($_SESSION["validUser"]){
                     //   echo "Secret Page";
                        $username=$_SESSION["user"];
                        $password=$_SESSION["pass"];

                        include 'open_connection_with_db.php';

                        $selectUsernameQuery="SELECT * FROM retailer WHERE username='$username'";

                        $result=mysqli_query($connection,$selectUsernameQuery);
                        $row=mysqli_fetch_assoc($result);
                        $ret_id=$row["retailer_id"];
                    }
                    else
                        {
                            echo "Signin First";
                            header('Location:index.php');
                        }
                }
            else
                {
                    echo "Signin First";
                    header('Location:index.php');
                }
            ?>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Shopper | Shop's Admin </title>

    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/custom.css" rel="stylesheet">

    <script type="text/javascript" src="js/respond.js"></script>
    <script type="text/javascript">
        function render_page(str){
               if (window.XMLHttpRequest) {
                    // code for IE7+, Firefox, Chrome, Opera, Safari
                    xmlhttp = new XMLHttpRequest();
                } else {
                    // code for IE6, IE5
                    xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
                }
                xmlhttp.onreadystatechange = function() {
                    if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
                        document.getElementById("ajaxView").innerHTML = xmlhttp.responseText;
                    }
                };

                var ans='<?php echo $ret_id; ?>';
                xmlhttp.open("GET","getViewatshopFrontEnd_ajax.php?q="+str+"&ret_id="+ans,true);
                xmlhttp.send();
        }

         function getCategories(caller,str) {
                if (window.XMLHttpRequest) {
                    // code for IE7+, Firefox, Chrome, Opera, Safari
                    xmlhttp = new XMLHttpRequest();
                } else {
                    // code for IE6, IE5
                    xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
                }
                if(caller=="insideeditSubcatscats"){         
                                document.getElementById("id_editedCategory").value=str;
                }
                xmlhttp.onreadystatechange = function() {
                    if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
                        if(caller=="insideSubcatAj")
                            document.getElementById("insideSubcatAj").innerHTML = xmlhttp.responseText;
                        else if(caller=="showForDelete")
                            document.getElementById("showForDelete").innerHTML = xmlhttp.responseText;
                        else if(caller=="insideProductDeleteAj")
                            document.getElementById("insideProductDeleteAj").innerHTML = xmlhttp.responseText;
                        else if(caller=="insideSubcatForDeleteAj")
                            document.getElementById("insideSubcatForDeleteAj").innerHTML = xmlhttp.responseText;
                        else if(caller=="insideeditSubcatscats")
                            document.getElementById("insideeditSubcatscats").innerHTML = xmlhttp.responseText;
                    }
                };

                var ans='<?php echo $ret_id; ?>';
                xmlhttp.open("GET","ajax_getsubcats.php?q="+str+"&ret_id="+ans,true);

                xmlhttp.send();       
        }
        
         function showUser4(str) {
                if (window.XMLHttpRequest) {
                    // code for IE7+, Firefox, Chrome, Opera, Safari
                    xmlhttp = new XMLHttpRequest();
                } else {
                    // code for IE6, IE5
                    xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
                }
                xmlhttp.onreadystatechange = function() {
                    if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {

                        document.getElementById("insideProductDeleteAj").innerHTML = xmlhttp.responseText;
                    }
                };

                var ans='<?php echo $ret_id; ?>';
                xmlhttp.open("GET","ajax_getproducts_ajax.php?q="+str+"&ret_id="+ans,true);
                xmlhttp.send();
           
        }


        function editCatVal(str){
            document.getElementById("id_editedSubcategory").value=str;
        }
         function showProductsDetails(str) {
                
                if (window.XMLHttpRequest) {
                    // code for IE7+, Firefox, Chrome, Opera, Safari
                    xmlhttp = new XMLHttpRequest();
                } else {
                    // code for IE6, IE5
                    xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
                }
                xmlhttp.onreadystatechange = function() {
                    if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
                        var detail=new Array();
                       detail=JSON.parse(xmlhttp.responseText);
                   // alert("Response : "+detail.price);
                       document.getElementById("update_pro_price").value = detail.price;
                       document.getElementById("update_pro_unit").value = detail.unit;
                       document.getElementById("update_pro_stock").value= detail.stock;
                       document.getElementById("update_pro_description").value= detail.description;
                    }
                };

                var ans='<?php echo $ret_id; ?>';
                xmlhttp.open("GET","ajax_getproductsdetails_ajax.php?q="+str+"&ret_id="+ans,true);
                xmlhttp.send();
           
        }
        

    </script>
</head>

<body style="background-color:#ddd;">


	<script src="http://code.jquery.com/jquery-latest.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    
    <!--Containner div-->
    <div class="containner" style="margin:auto;">           
            <div  style="margin-top:-23px;background:url('<?php echo "".$row["shop_cover_image_path"]; ?>') no-repeat center center;background-size: 100% 100%;height:35em;" >    
                    <h1 style="background-color:#222222;text-align:center;color:white;opacity:1; "><?php echo "".$row["shop_name"]."<br>".$row["shop_description"]; ?></h1>              
             </div>
             <div>
                <?php include 'menu_For_shop_admins.php' ?>
                                <?php
                    if ($_SERVER["REQUEST_METHOD"] == "POST" ){
                        if(isset($_POST['newCat'])){
                                $newCategory=$_POST['newCat'];

                        $cat_already="SELECT * FROM category WHERE retailer_id='$ret_id' AND name='$newCategory'";
                        
                            if(mysqli_num_rows(mysqli_query($connection,$cat_already)) <1  )
                            {

                                $insQuery="INSERT INTO category(name,retailer_id)
                                            VALUES('$newCategory','$ret_id')";

                                if(mysqli_query($connection,$insQuery))
                                {
                                    echo "
                                        <script type='text/javascript'>
                                            alert('Data Saved Succesfully');
                                        </script>
                                    ";
                                }else
                                {
                                   
                                    echo "
                                        <script type='text/javascript'>
                                            alert('Data Not Saved');
                                        </script>
                                    ";
                                }     
                            }else{

                                    echo "
                                        <script type='text/javascript'>
                                            alert('Already  added category ');
                                        </script>
                                    ";
                            }
                        }
                    }
                    ?>
                    <?php
                        if(isset($_POST['cats'])){
                                $cat_to_del=$_POST['cats'];

                                $delQuery="DELETE category FROM category WHERE name='$cat_to_del' AND retailer_id='$ret_id'";
                                
                                if (mysqli_query($connection, $delQuery)) {
                                   
                                    echo "
                                        <script type='text/javascript'>
                                            alert('Record deleted successfully');
                                        </script>
                                    ";

                                } else {
                                     echo "
                                        <script type='text/javascript'>
                                            alert('Error deleting category');
                                        </script>
                                    ";
                                }
                        }

                    ?>
                                        <?php

                        if(isset($_POST['newSubCat'])){
                                $subCat=$_POST['newSubCat'];
                                $selected_Cat=$_POST['sscats'];
                                
                                $ro=mysqli_query($connection,"SELECT cat_id FROM category WHERE name='$selected_Cat' and retailer_id='$ret_id' ");
                                $ro=mysqli_fetch_assoc($ro);
                                $cat_id =$ro["cat_id"];

                                $subcat_already="SELECT * from category,subcategory WHERE  category.retailer_id='$ret_id' AND 
                                category.cat_id=subcategory.cat_id AND  subcategory.cat_id='$cat_id' AND subcategory.name='$subCat'";
                                
                                 if(mysqli_num_rows(mysqli_query($connection,$subcat_already)) <1  )
                                 {
                                      $ins="INSERT INTO subcategory (name,cat_id) VALUES('$subCat','$cat_id')";

                                        if(mysqli_query($connection,$ins))
                                        {
                                            echo "
                                                <script type='text/javascript'>
                                                    alert('Data Saved Succesfully');
                                                </script>
                                            ";
                                        }else
                                        {
                                           
                                            echo "
                                                <script type='text/javascript'>
                                                    alert('Data Not Saved');
                                                </script>
                                            ";

                                        }
                                 }else{
                                      echo "
                                                <script type='text/javascript'>
                                                    alert('Exisisting subcategory');
                                                </script>
                                            ";
                                 }
                              
                        }
                    ?>

                     <?php

                        if(isset($_POST['subscats'])){
                                $cat_to_del=$_POST['subscats'];
                                
                                $delQuery="DELETE subcategory FROM subcategory,category WHERE subcategory.name='$cat_to_del' AND 
                                subcategory.cat_id=category.cat_id AND category.retailer_id='$ret_id'";
                                

                                if (mysqli_query($connection, $delQuery)) {
                                   
                                    echo "
                                        <script type='text/javascript'>
                                            alert('Record deleted successfully');
                                        </script>
                                    ";

                                } else {
                                     echo "
                                        <script type='text/javascript'>
                                            alert('Error deleting subcategory');
                                        </script>
                                    ";
                                }
                        }

                    ?>

                      <?php

                        if(isset($_POST['subscatsForNewProducts'])){
                           $subcate=$_POST['subscatsForNewProducts'];
                           
                           $pro_name=$_POST['pro_name'];
                           $pro_price=$_POST['pro_price'];
                           $pro_unit=$_POST['pro_unit'];
                           $pro_stock=$_POST['pro_stock'];
                           $pro_description=$_POST['pro_description'];


                           $check_already_exist_product="SELECT * FROM product,category,subcategory  WHERE category.retailer_id='$ret_id' 
                                                         AND category.cat_id=subcategory.cat_id AND subcategory.subcat_id=product.subcat_id
                                                         AND product.name='$pro_name' ";

                           if(mysqli_num_rows(mysqli_query($connection,$check_already_exist_product)) <1  )
                            {

                                    $target_dir = "uploads/";
                                    $target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);
                                    $uploadOk = 1;
                                    $uploadComplete=0;

                                    $imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);
                                    // Check if image file is a actual image or fake image
                                    if(isset($_POST["submit"])) {
                                        $check = getimagesize($_FILES["fileToUpload"]["tmp_name"]);
                                        if($check !== false) {
                                            $uploadOk = 1;
                                        }
                                    }
                                    // Allow certain file formats
                                    if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
                                    && $imageFileType != "gif" ) {
                                        echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
                                        $uploadOk = 0;
                                    }
                                    // Check if $uploadOk is set to 0 by an error
                                    if ($uploadOk == 0) {
                                        echo "Sorry, your file was not uploaded.";
                                        
                                    // if everything is ok, try to upload file
                                    } else {
                                        if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) {
                                            $uploadComplete=1;
                                        } else {
                                            echo "Sorry, there was an error uploading your file.";
                                        }
                                    }

                                    if($uploadComplete!=0){
                                        

                                        $select_subcat_id="SELECT * FROM subcategory,category WHERE subcategory.name='$subcate' AND 
                                                                    category.cat_id=subcategory.cat_id AND category.retailer_id='$ret_id'";

                                        $select_subcat_id=mysqli_query($connection,$select_subcat_id);
                                        $select_subcat_id=mysqli_fetch_assoc($select_subcat_id);
                                        $select_subcat_id =$select_subcat_id["subcat_id"];

                                        $already_product_exist="SELECT * FROM product WHERE name='$select_subcat_id' ";
                                        if((mysqli_num_rows(mysqli_query($connection,$already_product_exist)))<1)
                                        {

                                            $INSERT_NEW_PRODUCT="INSERT into product(name,price,unit,stock,description,image,subcat_id)
                                                    VALUES('$pro_name','$pro_price','$pro_unit','$pro_stock','$pro_description','$target_file','$select_subcat_id')";
                                            
                                            if(mysqli_query($connection,$INSERT_NEW_PRODUCT))
                                            {
                                                echo "
                                                    <script type='text/javascript'>
                                                        alert('Product Saved Succesfully');
                                                    </script>
                                                ";
                                            }else
                                            {
                                               
                                                echo "
                                                    <script type='text/javascript'>
                                                        alert('Product Not Saved');
                                                    </script>
                                                ";

                                            }   


                                        }

                                    }else{
                                         echo "
                                                <script type='text/javascript'>
                                                    alert('Problem in image uploading');
                                                </script>
                                            ";
                                    }


                            }else{

                                     echo "
                                        <script type='text/javascript'>
                                            alert('Product Exist Already...');
                                        </script>
                                    ";
                            }

                        }

                    ?>

                <?php
                    if(isset($_POST["update_cat"])){
                                                                        
                        $up_cat=$_POST["name_editedCategory"];
                        $old=$_POST["editcatsSubcats"];

                        $up_cat_query="UPDATE category set name='$up_cat' WHERE retailer_id='$ret_id' AND name='$old'";
                        if(mysqli_query($connection,$up_cat_query)){
                            echo "
                                <script type='text/javascript'>
                                    alert('Category updated'    );
                                </script>
                            ";
                        }else{
                           echo "
                                <script type='text/javascript'>
                                    alert('Category didn't updated');
                                </script>
                            "; 
                        }

                    }else if(isset($_POST["update_subcat"])){
                        $newname=$_POST["name_editedSubcategory"];
                        $oldSubcat=$_POST["editSubcatscats"];
                        
                        $up_sub_cat="UPDATE subcategory JOIN category ON category.cat_id=subcategory.cat_id
                                    SET subcategory.name='$newname' WHERE category.retailer_id='$ret_id' AND 
                                    subcategory.name='$oldSubcat'";
                           if(mysqli_query($connection,$up_sub_cat)){
                            echo "
                                <script type='text/javascript'>
                                    alert('Subcategory updated'    );
                                </script>
                            ";
                        }else{
                           echo "
                                <script type='text/javascript'>
                                    alert('Subcategory didn't updated');
                                </script>
                            "; 
                        }

                    }
                ?>

             </div>
             <div class="row" id="ajaxView" style="min-height:300px;">

             </div>
             <?php
                include 'footer.php';
             ?>
    </div>
</body>
</html>
