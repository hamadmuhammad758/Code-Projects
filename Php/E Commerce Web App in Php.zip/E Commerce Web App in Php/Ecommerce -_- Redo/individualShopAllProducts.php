<!doctype html><!---->
<html>
<head>
    <?php
        include'open_connection_with_db.php';
        $ret_id=$_GET["retailer"];
        $shopdata="SELECT * FROM retailer where retailer_id='$ret_id'";
        $res=mysqli_query($connection,$shopdata);
        if(mysqli_num_rows($res)>0){
            while($r=mysqli_fetch_assoc($res)){
                    $shopCover=$r["shop_cover_image_path"];
                    $shopDesc=$r["shop_description"]; 
                    $shopName=$r["shop_name"];        
            }
        }
        ?>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Shopper | In </title>

    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/custom.css" rel="stylesheet">

    <script type="text/javascript" src="js/respond.js"></script>
</head>

<body style="background-color:black;">


	<script src="http://code.jquery.com/jquery-latest.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    
    <!--Containner div-->
    <div class="containner" style="margin:auto;">
			<?php
					include 'main_Menu.php';
            ?>

              <div  style="opacity:;margin-top:-23px;margin-bottom:20px;background:url('<?php echo "".$shopCover; ?>') no-repeat center center;background-size: 100% 100%;height:35em;" >    
                        <h1 style="background-color:#222222;text-align:center;color:white;opacity:1; "><?php echo "".$shopName."<br>".$shopDesc; ?></h1>                  
              </div>

              <div class="row">
                      <div class="panel panel-success col col-md-3  "  style="margin-left:40px;" >
                        
                    <h1 class="panel-heading">Categories</h1>
                    <ul class="panel-body nav nav-pills nav-stacked ">
                        
                        <?php
                                $allCategories=array();
                                $selectCats="SELECT subcategory.name From subcategory,category WHERE 
                                subcategory.cat_id=category.cat_id   AND category.retailer_id='$ret_id'";
                                $r=mysqli_query($connection,$selectCats);

                                if (mysqli_num_rows($r) > 0) {
                                    while($ro = mysqli_fetch_assoc($r)) {
                                        echo "<li><a href='individualShopAllProducts.php?retailer=".$ret_id."&selectedCategory=".$ro["name"]."'>".$ro["name"]."</a></li>";
                                    }
                                }
                        ?>

                            <!--    <li><a href="#">Gallery</a></li> -->
                    </ul>       
                </div>

                <div class="col col-sm-8" style="margin-left:20px;min-height:500px;background:white;padding:20px;" >
                        <?php
                            if(isset($_GET['selectedCategory'])){
                            
                            $sC=$_GET['selectedCategory'];

                            $getProductOfThisCategory="SELECT * from category,subcategory,product where 
                                                        category.retailer_id='$ret_id'
                                                        AND category.cat_id=subcategory.cat_id
                                                        AND subcategory.name='$sC'
                                                        AND subcategory.subcat_id=product.subcat_id";

                            $r=mysqli_query($connection,$getProductOfThisCategory);

                            if (mysqli_num_rows($r) > 0) {
                                    while($ro = mysqli_fetch_assoc($r)) {   
                                        echo"
                                            <div style='background:;width:150px;height:300px;margin:10px;display:inline-block;text-align:center;'>
                                                <img src='".$ro["image"]."' style='width:120px;height:120px;margin-left:auto;margin-right:auto;display:block ;'/>
                                                <p style='margin:5px;color:black;text-align:center;'>".
                                                    $ro["name"]
                                                ."</p>
                                                <p style='margin:5px;color:black;text-align:center;'>".
                                                    $ro["price"]." ".$ro["unit"]
                                                ."</p>
                                                      <button type='button' class='btn btn-primary'>
                                                        <a style='color:white;' href='redirection_for_individual_shop.php?p_id=".$ro["product_id"]."'>Buy Now</a>
                                                     </button>                               
                                            </div>
                                        ";
                                    }
                            }                            
                        }
                        ?>
                </div>
        </div>

              </div>

    </div>
</body>
</html>
