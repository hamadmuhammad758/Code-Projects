<!doctype html><!---->
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Shopper | Index </title>


    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/custom.css" rel="stylesheet">

    <script type="text/javascript" src="js/respond.js"></script>
</head>

<body style="background-color:#ddd;">    
    <!--Containner div-->
    <div class="containner" style="margin:auto;">
    	
        <!--Main Navigaiton -->
            <?php
                include 'main_Menu.php';
            ?>
        <!--Main Navigaiton -->

    	<div class="jumbotron" style="margin-top:-20px;background:url('img/mainjumb.jpg') no-repeat center center;
    	background-size: 100% 100%;height:35em;">  		
    	</div>
    	<!-- Main Jumbotron-->
        
        <div class="row" style="background-color:#13181B;margin-top:40px;margin-bottom:40px;"><!-- 5th Row -->
            <h1 style="text-align:center;margin:50px;color:#ffffff;font-weight:bold;">
                Join us today and start you online business with us!
            </h1>
        </div> <!-- 5th Row -->

    	<!-- Second Row-->

    	<div class="row " >
  			
			<!-- article about shopper-->
    		<div class="panel panel-info	col col-sm-8 col-sm-offset-2"   >
    			<h1 class="panel-heading">Who we are ?</h1>
    			<article class="panel-body">
    					Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis ornare ipsum purus, et sagittis enim faucibus sit amet. Ut dolor tellus, bibendum vel risus sed, blandit auctor enim. Sed tristique sodales quam, id commodo leo auctor id. Vestibulum in ligula rhoncus erat rhoncus gravida. Nulla rhoncus magna elementum, varius lacus sed, auctor justo. Suspendisse convallis tristique mauris vel volutpat. Suspendisse dui nunc, facilisis et interdum quis, volutpat eget ipsum. Nunc dapibus sollicitudin felis, eget interdum eros ornare et. Mauris id quam sed dolor vulputate fringilla. Cras sit amet felis nec lectus laoreet viverra. Aliquam erat volutpat. Proin finibus orci in urna ornare, vitae finibus justo scelerisque. Nam libero felis, posuere in elit sit amet, ullamcorper semper ex. Quisque ultrices ullamcorper dui, sed maximus sapien vulputate nec. Maecenas vitae tempor erat, at sodales odio.Phasellus sit amet massa in ligula consectetur maximus. Nam quis nisi quis sem ultricies eleifend. Ut ut gravida velit.
    			</article>	
    		</div>
    
        </div>  	<!-- Second Row-->
  

        <div class="row" style="background-color:#13181B;margin-top:12px;margin-bottom:35px;"><!-- Second Row -->
            <h1 style="text-align:center;margin:50px;color:#ffffff;font-weight:bold;">Our Team</h1>
        </div> <!-- Second Row -->

        <div class="row" style="background-color:#D9EDF7;padding-top:35px;padding-bottom:35px;">   <!-- Third Row-->    

            <div class=" col col-sm-2 col-sm-offset-2 col-xs-6 " style="padding:1px;" ><!-- -->
                <img class=" img-thumbnail img-responsive" src="img/men1.jpg" style="height:250px;width:330px;"/>
            </div><!-- -->

            <div class="col col-sm-2 col-xs-6"style="padding:1px; " ><!-- -->       
                <img class=" img-thumbnail  img-responsive" src="img/men2.jpg" style="height:250px;width:330px;" />
            </div><!-- -->

            <div class="col col-sm-2 col-xs-6"style="padding:1px;" ><!-- -->
                <img class="  img-thumbnail img-responsive" src="img/men3.jpg" style="height:250px;width:330px;" />
            </div><!-- -->

            <div class="col col-sm-2 col-xs-6"style="padding:1px;" ><!-- -->
                <img class=" img-thumbnail  img-responsive" src="img/men4.jpg" style="height:250px;width:330px;" />
            </div><!-- -->

        </div><!--Third Row -->

        <div class="row" id="abcd" style="background-color:#D9EDF7;padding-top:35px;padding-bottom:35px;padding-left:5px;padding-right:5px;"  >  <!-- 4th Row-->
            <div class="col col-sm-8 col-sm-offset-2">
                  <p>  Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis ornare ipsum purus, et sagittis enim faucibus sit amet. Ut dolor tellus, bibendum vel risus sed, blandit auctor enim. Sed tristique sodales quam, id commodo leo auctor id. Vestibulum in ligula rhoncus erat rhoncus gravida. Nulla rhoncus magna elementum, varius lacus sed, auctor justo.
                  </p> 
            </div>
        </div> <!-- 4th row-->
        

        <div class="row" style="background-color:#13181B;margin-top:40px;margin-bottom:40px;"><!-- 5th Row -->
            <h1 style="text-align:center;margin:50px;color:#ffffff;font-weight:bold;">
                Join us today and start you online business with us!
            </h1>
        </div> <!-- 5th Row -->

       <?php   include 'footer.php';   ?>

    <div>    <!--Containner div-->


    <script src="http://code.jquery.com/jquery-latest.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery-2.1.4.js"></script>
    
</body>
</html>
