
				<?php

		                $connection = new mysqli("localhost", "root","","shopper");
		                
		                if ($connection->connect_error) 
		                    die("Connection failed with database");
		          ?>	
