<?php
	
	session_start();
	if(!(isset($_SESSION["addtoCart"]))){
		$_SESSION["addtoCart"]=1;
		$_SESSION["products_in_cart"]=array();
		$_SESSION["counts"]=0;
		$_SESSION["products_in_cart"][0]=$_GET["prod"];
	}else{
		$_SESSION["counts"]=$_SESSION["counts"]+1;
		$c=$_SESSION["counts"];
		$_SESSION["products_in_cart"][$c]=$_GET["prod"];
		foreach ($_SESSION["products_in_cart"] as $key ) {
			echo "products_in_cart : ". $key."<br>";
		}
	}
	header('location:individualShop.php')
?>