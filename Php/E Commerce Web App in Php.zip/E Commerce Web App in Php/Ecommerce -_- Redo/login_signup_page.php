<!doctype html><!---->
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Shopper | In</title>

    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/custom.css" rel="stylesheet">

    <script type="text/javascript" src="js/respond.js"></script>
    
    <script type="text/javascript">
          
          function validateLogin(){
             var flag=1;
             if(((document.getElementById("id_log_user").value).trim())=="" ||
                ((document.getElementById("id_log_pass").value).trim())==""){
                
                document.getElementById("errorLoginSpan").innerHTML="* Empty Fields are not Allowed..";
                flag=0;
             }else{
                var x=document.getElementById("id_log_user").value;
              
              if(x.length>4)
              { 
                for(var i=0 ; i<x.length ; i++)
                  if(!((x[i]>="a" && x[i]<="z") ||(x[i]>="A" && x[i]<="Z")))
                   {
                    document.getElementById("errorLoginSpan").innerHTML="* Only alphabets are allowed in username";
                    flag=0;
                    break;
                   }
              }else{
                 document.getElementById("errorLoginSpan").innerHTML="* Username should be atleast 4 characters long...";
                 flag=0;
               }


               if(flag){
                //check pass should be 8 characters long
                var x=document.getElementById("id_log_pass").value;
                if(x.length<4){
                  flag=0;
                  document.getElementById("errorLoginSpan").innerHTML="* Password should be atleast 4 characters long...";
                }
              }


             }

            if(!flag){
              return false;
            }else
              return true;
            
          }

          function lastC(){
             var flag=1;
             if(((document.getElementById("txt_username").value).trim())=="" ||
                ((document.getElementById("txt_password").value).trim())=="" ||
                ((document.getElementById("eml_email").value).trim())=="" ||
                ((document.getElementById("txt_ShopName").value).trim())=="" ||
                ((document.getElementById("txt_description").value).trim())==""
              ){
              //Check if fields are not empty...
                flag=0;
                document.getElementById("errorSignupSpan").innerHTML="* Empty Fields are not Allowed..";
             }else{
              //check username must be alphabet and atleast 4 characters long
              var x=document.getElementById("txt_username").value;
              
              if(x.length>4)
              { 
                for(var i=0 ; i<x.length ; i++)
                              if(!((x[i]>="a" && x[i]<="z") ||(x[i]>="A" && x[i]<="Z")))
                               {
                                document.getElementById("errorSignupSpan").innerHTML="* Only alphabets are allowed in username";
                                flag=0;
                                break;
                               }
              }else{
                 document.getElementById("errorSignupSpan").innerHTML="* Username should be atleast 4 characters long...";
                 flag=0;
               }
               if(flag){
                //check pass should be 8 characters long
                var x=document.getElementById("txt_password").value;
                if(x.length<4){
                  flag=0;
                  document.getElementById("errorSignupSpan").innerHTML="* Password should be atleast 4 characters long...";
                }
                if(flag){
                  //check if email is valid
                  var x=document.getElementById("eml_email").value;
                  var pattern=/^([a-zA-Z0-9_.-])+@([a-zA-Z0-9_.-])+\.([a-zA-Z])+([a-zA-Z])+/;
                  if(!(pattern.test(x))){
                    flag=0;
                    document.getElementById("errorSignupSpan").innerHTML="* Invalid email address...";
                  }
                }
               }
             }

            if(!flag){
              return false;
            }else
              return true;
          }
    </script>

</head>

<body style="background-color:#ddd;">


    <script src="js/jquery-2.1.4.js"></script>
    <script src="js/bootstrap.min.js"></script>
    
    <!--Containner div-->
    <div class="containner" style="margin:auto;">



<?php
					          include 'main_Menu.php';       
?>
            <div class="row">
                <div class="col col-md-4 col-sm-offset-4">
                     <h1 style="text-align:center;">Login</h1>
                     <form action="logme.php" method="post">
                        <div class="form-group">
                            <input type="text" class="form-control" name="name_user"  id="id_log_user" class="cl_user" placeholder="Username"/>
                            <input type="password" class="form-control" name="name_pass"  id="id_log_pass" class="cl_user" placeholder="password" style="margin-top:20px;"/>
                        </div>
                        <div class="form-group">
                            <input type="submit" name="login_button" class="btn btn-primary" onclick="return validateLogin()" value="Login">
                            <span id="errorLoginSpan" style="color:red;">
<?php
                                    if(isset($_GET["logine"])){
                                        $log=$_GET["logine"];
                                        if($log=="not"){
                                            echo"Invalid user";
                                        }
                                      }
?>
                            <span>
                      </div>
                </form>
                </div>
            </div>
                    <div class="row" >
                       <div class="col col-md-4 col-sm-offset-4">
                            <h1 style="text-align:center;">Signup</h1>
                             <div class="form-group">
                                     <form  action="saveNewRetailShop.php" method="post"  enctype="multipart/form-data">
                                      
                                      <div class="form-group" >
                                        <input type="text" class="form-control"  placeholder="Username" name="username" id="txt_username"     maxlength="20" >
                                      </div>

                                      <div class="form-group">
                                        <input type="password" class="form-control"  placeholder="Password" name="password"   id="txt_password"  maxlength="20">
                                      </div>

                                      
                                      <div class="form-group">
                                        <input type="email" class="form-control"  placeholder="email" name="email"    id="eml_email" maxlength="30">
                                      </div>

                                      <div class="form-group">
                                        <input type="text" class="form-control"   placeholder="Shop name" name="shopname"   id="txt_ShopName" maxlength="20"  >
                                      </div>          
                                      
                                      <div class="form-group">
                                    <!--    <input type="text" class="form-control"  placeholder="Shop Description"  name="description"  id="txt_description"  maxlength="100">
                                      --></div>
                                      <textarea  placeholder="Shop Description"   name="description"  id="txt_description">
                                      </textarea>
                                      
                                        <input type="file" class="btn btn-default" name="fileToUpload" id="fileToUpload">
                                      
                                       <input type="submit" name="submit" class="btn btn-default" style="margin-top:20px;" onclick="return lastC()" value="Sign up">

                                       
                            </div>

                                        <span id="errorSignupSpan" style="color:red;">
                                            <?php
                                                     if(isset($_GET["error"])){

                                                        $e=$_GET["error"];
                                                        switch ($e) {                                                           
                                                            case "1":
                                                                    echo "Invalid Email Address ";
                                                                break;
                                                            
                                                            case '2':
                                                                    echo "Error Uploading Image";
                                                                break;
                                                            
                                                            case '3':
                                                                    echo "Username Already Exists";
                                                                break;
                                                            
                                                            case '4':
                                                                    echo "Email Already Exists";
                                                                break;
                                                            
                                                            case '5':
                                                            
                                                                    echo "Congratulations , Your shop has been cretaed ";
                                                                break;
                                                            
                                                            case "6":
                                                            
                                                                    echo "Retry ! Something went wrong'";
                                                                break;
                                                            
                                                            default:
                                                                # code...
                                                                break;
                                                        }
                                                    } 
                                            ?>
                                        <span>
                </div>
            </div>
    </div>
</body>
</html>

