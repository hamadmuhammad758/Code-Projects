<?php
	
	$name=$_GET["names"];
	$comment=$_GET["comments"];
	$product_id=$_GET["prod"];

	include 'open_connection_with_db.php';
	$insertQuery="INSERT INTO  comment(date_time,description,product_id,name) VALUES(NOW(),'$comment','$product_id','$name')";
	$sav=mysqli_query($connection,$insertQuery);
?>