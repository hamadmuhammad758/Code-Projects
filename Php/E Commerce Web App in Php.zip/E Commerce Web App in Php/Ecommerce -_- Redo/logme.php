<?php
    //login me
    
    
                    include 'open_connection_with_db.php';

                    if(isset($_POST["login_button"])){

                          $users=$_POST["name_user"];
                          $passs=$_POST["name_pass"];


                                $selectQuery="SELECT * FROM retailer WHERE username='$users' and password='$passs'";
                                $result=mysqli_query($connection,$selectQuery);

                                if(mysqli_num_rows($result)>0)
                                {
                                     echo "<h1 style='text-align:center;'>Welcome To shop<br></h1>";

                                     session_start();
                                     $_SESSION["validUser"]=1;
                                     $_SESSION["user"]=$users;
                                     $_SESSION["pass"]=$passs;
                                     header('Location:shopFrontEnd.php');

                                }else {                       
                                     header('Location:login_signup_page.php?logine=not'); 
                                }                    
                    }
?>