<?php
	                          
                        session_start();
                        unset($_SESSION['validUser']);
                        unset($_SESSION['user']);
                        unset($_SESSION['pass']);
                        session_destroy();
                        header('Location:index.php');
?>