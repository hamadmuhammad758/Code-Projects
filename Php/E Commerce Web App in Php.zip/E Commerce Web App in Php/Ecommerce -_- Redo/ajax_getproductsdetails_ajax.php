<?php

                $connection = new mysqli("localhost", "root","","shopper");
                
                if ($connection->connect_error) 
                    die("Connection failed with database");
               
                $q = $_GET['q'];
                $ret_id=$_GET['ret_id'];

                $selecSubcat="SELECT * from category,subcategory,product 
                              WHERE category.retailer_id='$ret_id' AND category.cat_id=subcategory.cat_id
                              AND subcategory.subcat_id=product.subcat_id AND  product.name='$q'";

                 $r=mysqli_query($connection,$selecSubcat);

                 $returning_value=array();

                                    if (mysqli_num_rows($r) > 0) {
                                        while($ro = mysqli_fetch_assoc($r)) {
                                            $returning_value['name']=$ro["name"];
                                            $returning_value['price']=$ro["price"];
                                            $returning_value['description']=$ro["description"];
                                            $returning_value['stock']=$ro["stock"];
                                            $returning_value['unit']=$ro["unit"];
                                        }
                                    }
                         echo json_encode($returning_value, JSON_PRETTY_PRINT);
                           // echo "".mysqli_num_rows($r)."return name : ".$returning_value['name'];
?>