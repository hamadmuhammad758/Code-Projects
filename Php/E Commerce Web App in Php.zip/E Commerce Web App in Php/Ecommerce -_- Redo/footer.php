<?php
	
	echo "
		 <div class='row' style='background-color:#D9EDF7;border-top:1px solid #ddd;text-align:center;padding:50px;margin-bottom:0px;'> <!-- 6th row-->

            <footer>
                <small>
                    <p>
                        This is actually the footer of our website . I put here some random text form the site www.lipsum.com.Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis ornare ipsum purus, et sagittis enim faucibus sit amet. Ut dolor tellus, bibendum vel risus sed.
                    </p>
                </small>
            </footer>

        </div>  <!-- 6th row-->
	";

?>