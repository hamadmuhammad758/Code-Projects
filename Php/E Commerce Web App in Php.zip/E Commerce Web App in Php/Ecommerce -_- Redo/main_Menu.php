<?php
	echo "
    
    <!--Containner div-->
    <div class='containner' >
    	<!--Main Navigation -->
    	
    		<nav class='navbar navbar-default navbar-fixed navbar-inverse' role='Navigation'>
    			<!--navbar-header-->
    			<div class='navbar-header'>
    				
    				<button type='button' class='navbar-toggle' data-target='collapse' data-toggle='collapse'> 

    				<span class='sr-only'>Toggle navigation</span>
                    <span class='icon-bar'></span>
                    <span class='icon-bar'></span>
                    <span class='icon-bar'></spanx	>
    				</button>
				</div>
				<!--navbar-header-->

				<!-- navbar-collapse -->
    			<div class='collapse navbar-collapse' id='collapse'>
    				
    				<ul class='nav navbar-nav'>
    					<li ><a href='#abcd'>Home</a></li>
    					<li><a href='allShops.php'>Browse Shops</a></li>
    					<li><a href='checkout.php'>Checkout</a></li>
    					<li><a href='#'>Contact us</a></li>
    				</ul>
    				<form class='navbar-form navbar-right' role='Login' method='post' action='retailer_login.php'>
					  <div class='form-group'>
					  <button type='button' class='btn btn-default'>
                        <a href='login_signup_page.php'>Login/Register</a>
                     </button>
                       </div>
					</form>
                    
    			</div>
    			<!-- navbar-collapse -->
    		</nav>
    		</div><!-- Main Navigation -->


	";	
?>