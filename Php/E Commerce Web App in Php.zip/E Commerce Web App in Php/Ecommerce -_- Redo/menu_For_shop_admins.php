<?php
$add="ad";
    echo "

                     <div class='row' >
                 <nav class='navbar navbar-default navbar-fixed navbar-inverse' role='Navigation'>
                        <!--navbar-header-->
                        <div class='navbar-header'>
                            
                            <button type='button' class='navbar-toggle' data-target='collapse' data-toggle='collapse'> 

                            <span class='sr-only'>Toggle navigation</span>
                            <span class='icon-bar'></span>
                            <span class='icon-bar'></span>
                            <span class='icon-bar'></spanx  >
                            </button>
                        </div>
                        <!--navbar-header-->

                        <!-- navbar-collapse -->
                        <div class='collapse navbar-collapse' id='collapse'>
                            
                            <ul class='nav navbar-nav'>
                                <li ><a href='individualShop.php'>My Shop</a></li>
                                      <li class='dropdown'>
                                          <a href='#' class='dropdown-toggle' data-toggle='dropdown' role='button' aria-haspopup='true' aria-expanded='false'>Manage Categories<span class='caret'></span></a>
                                          <ul class='dropdown-menu'>
                                            <li onclick='render_page(\"addCategory\")'><a>Add Category</a></li>
                                            <li onclick='render_page(\"deleteCategory\")'><a>Delete Category</a></li>
                                            <li onclick='render_page(\"addSubcategory\")'><a>Add Subcategory</a></li>
                                            <li onclick='render_page(\"deleteSubcategory\")'><a>Delete Subcategory</a></li>
                                            <li onclick='render_page(\"editCategories\")'><a>Edit Categories/Subcategories</a></li>
                                            
                                          </ul>
                                    </li>
                                    <li class='dropdown'>
                                          <a href='#' class='dropdown-toggle' data-toggle='dropdown' role='button' aria-haspopup='true' aria-expanded='false'>Manage Products<span class='caret'></span></a>
                                          <ul class='dropdown-menu'>
                                            <li onclick='render_page(\"addProduct\")'><a>Add Product</a></li>
                                            <li onclick='render_page(\"editProduct\")'><a>Edit/Delete Product</a></li>                
                                          </ul>
                                    </li>
                                <li><a href='#'></a></li>
                            </ul>
                        </div>

                        <!-- navbar-collapse -->
                    </nav>
            </div>
            


    ";

?>