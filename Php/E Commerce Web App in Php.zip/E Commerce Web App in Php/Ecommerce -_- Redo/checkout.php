<!doctype html><!---->
<html>
<head>
    <?php
                        $distinctProducts=array();
                        $count=0;
                        $stockInProducts=array();
                        $totalPrice=0;
    ?>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Shopper | Checkout</title>

    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/custom.css" rel="stylesheet">

    <script type="text/javascript" src="js/respond.js"></script>
    <script type="text/javascript">
        function incStock(str){
            var totPrice=document.getElementById("tprice").innerHTML;
            var proPrc=document.getElementById("proPrice"+str).innerHTML;
            var proStock=document.getElementById("proStock"+str).innerHTML;
            

            document.getElementById("tprice").innerHTML=parseInt(totPrice)+parseInt(proPrc);
            document.getElementById("proStock"+str).innerHTML=parseInt(proStock)+1;

        }
        function decStock(str){
            var totPrice=document.getElementById("tprice").innerHTML;
            var proPrc=document.getElementById("proPrice"+str).innerHTML;
            var proStock=document.getElementById("proStock"+str).innerHTML;
            
            document.getElementById("tprice").innerHTML=parseInt(totPrice)-parseInt(proPrc);
            document.getElementById("proStock"+str).innerHTML=parseInt(proStock)-1;

        }
    </script>
</head>

<body style="background-color:black;">


    <script src="js/jquery-2.1.4.js"></script>
    <script src="js/bootstrap.min.js"></script>
    
    <!--Containner div-->
    <div class="containner" style="margin:auto;">
			<?php
					include 'main_Menu.php';
            ?>

        <div class="jumbotron" style="margin-top:-20px;background:url('img/mainjumb.jpg') no-repeat center center;
        background-size: 100% 100%;height:35em;">       
        </div>

        <h1 style="color:white;">
            <?php 
                session_start();
                    if(isset($_SESSION["products_in_cart"])){
                        

                        foreach ($_SESSION["products_in_cart"] as $key ) {
                            if(!(in_array($key, $distinctProducts))){
                                $distinctProducts[$count]=$key;

                                $tmp = array_count_values($_SESSION["products_in_cart"]);
                                $cnt = $tmp[$key];
                                
                                $stockInProducts[$count]=$cnt;
                                $count++;

                            }
                    }
                   echo '
                    <div class="panel panel-success col col-sm-7" style="color:black;min-height:300px;margin-left:30px;margin-bottom:20px;">
                            <h1 class="panel panel-heading">Place your order</h1>
                            <div class="panel panel-body">
                                <table class="table  table-striped table-hover" style="font-size:medium;text-align:center;">
                                    <tr style="font-weight:bold;">
                                        <td>Image</td>
                                        <td>Name</td>   
                                        <td>Price</td>   
                                        <td>Total Items</td>
                                    </tr>';
                                    $cc=0;$totalPrice=0;
                                    include 'open_connection_with_db.php';
                                    foreach ($distinctProducts as $key) {
                                        
                                        $selQuery="SELECT * FROM product WHERE product_id='$key'";
                                        

                                        $res=mysqli_query($connection,$selQuery);
                                        $r=mysqli_fetch_assoc($res);
                                        $totalPrice=$totalPrice+$r["price"];

                                        echo'
                                            <tr>
                                                <td class="thumbnail"><img style="width:60px;" src="'.$r["image"].'"></td>
                                                <td>'.$r["name"].'</td>
                                                <td id="proPrice'.$cc.'" >'.$r["price"].'</td>
                                                <td id="proStock'.$cc.'">'.$stockInProducts[$cc].'</td>
                                                <td>
                                                    <button class="btn btn-info" onclick="incStock(\''.$cc.'\')" >+
                                                    </button>
                                                    <button class="btn btn-warning" onclick="decStock(\''.$cc.'\')" >-
                                                    </button>
                                                </td>
                                            </tr>
                                        ';
                                        $cc++;
                                    }

                        echo '
                            <tr>
                                <td></td>
                                <td  style="font-weight:bold;">Total amount : </td>
                                <td style="font-weight:bold;" id="tprice">'.$totalPrice.'</td>
                                <td></td>
                            </tr>
                        ';
                     echo'</table></div></div>';                     
                     echo '
                        <div class="panel panel-success col col-sm-4" style="color:black;min-height:300px;margin-left:30px;margin-bottom:20px;">
                                <h1 class="panel panel-heading">Your Details</h1>
                                <div class="panel panel-body">
                                    
                                 <form action="" method="post">
                                   <div class="form-group">
                                        <input type="text" class="form-control" name="name_user" required id="id_user" class="cl_user" placeholder="Name"/>
                                        <input type="text" class="form-control" name="name_pass" required id="id_user" class="cl_user" placeholder="Phone #" style="margin-top:20px;"/>
                                        <input type="text" class="form-control" name="name_pass" required id="id_user" class="cl_user" placeholder="email" style="margin-top:20px;"/>
                                       
                                    </div>
                                     <p style="font-size:25px;">Address</p>
                                     <textarea>
                                    </textarea>
                                    <input type="submit" value="Place Order" class="btn btn-success "/>
                                 </form>

                                </div>
                        </div>';

                    }else{
                            //echo "No Products in cart";  
                    }
                
            ?>
        </h1>
        <div class="row" style="background-color:white;margin-top:20px;min-height:200px;margin-bottom:20px;">

        </div>
        <?php
            include 'footer.php';
        ?>
    </div>
</body>
</html>
