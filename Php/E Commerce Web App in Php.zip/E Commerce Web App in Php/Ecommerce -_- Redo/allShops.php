<!-- All shops Redirection Link -->

<!doctype html><!---->
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Shopper | In</title>

    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/custom.css" rel="stylesheet">

    <script type="text/javascript" src="js/respond.js"></script>

				<?php

		                $connection = new mysqli("localhost", "root","","shopper");
		                
		                if ($connection->connect_error) 
		                    die("Connection failed with database");
		          ?>	

</head>

<body style="background-color:#000;">


	<script src="http://code.jquery.com/jquery-latest.min.js"></script>
    <script src="js/bootstrap.min.js"></script>

    <script type="text/javascript">
    	function showUser(scat){
    		alert(''+scat);
    	}
    </script>
    <!--Containner div-->
    <div class="containner" style="margin:auto;">
			<?php
					include 'main_Menu.php';			         
            ?>
        <!-- Main Jumbotron-->    
    	<div class="jumbotron" style="margin-top:-20px;background:url('img/mainjumb.jpg') no-repeat center center;
    	background-size: 100% 100%;height:35em;">  		
    	</div>
    	<!-- Main Jumbotron-->
    	<div class="row">

			<!-- first right Panel -->
				<div class="panel panel-success col col-md-3  "  style="margin-left:40px;" >
						
					<h1 class="panel-heading">Categories</h1>
					<ul class="panel-body nav nav-pills nav-stacked ">
						
						<?php
								$allCategories=array();
								$selectCats="SELECT DISTINCT name From subcategory ";
								$r=mysqli_query($connection,$selectCats);

			                    if (mysqli_num_rows($r) > 0) {
			                        while($ro = mysqli_fetch_assoc($r)) {
			                            echo "<li><a href='allshops.php?selectedCategory=".$ro["name"]."'>".$ro["name"]."</a></li>";
			                        }
			                    }
			  ?>

							<!--	<li><a href="#">Gallery</a></li> -->
					</ul>		
				</div>

				<div class="col col-sm-8" style="margin-left:20px;min-height:500px;background:white;padding:20px;" >
						<?php
							if(isset($_GET['selectedCategory'])){
		                	
		                	$sC=$_GET['selectedCategory'];

                            $getProductOfThisCategory="SELECT * from subcategory,product where subcategory.name='$sC'
                            							AND subcategory.subcat_id=product.subcat_id";

							$r=mysqli_query($connection,$getProductOfThisCategory);

		                    if (mysqli_num_rows($r) > 0) {
			                        while($ro = mysqli_fetch_assoc($r)) {	
			                        	echo"
			                        		<div style='background:;width:150px;height:300px;margin:10px;display:inline-block;text-align:center;'>
			                        			<img src='".$ro["image"]."' style='width:120px;height:120px;margin-left:auto;margin-right:auto;display:block ;'/>
			                        			<p style='margin:5px;color:black;text-align:center;'>".
			                        				$ro["name"]
			                        			."</p>
			                        			<p style='margin:5px;color:black;text-align:center;'>".
			                        				$ro["price"]." ".$ro["unit"]
			                        			."</p>
													  <button type='button' class='btn btn-primary'>
								                        <a style='color:white;' href='redirection_for_individual_shop.php?p_id=".$ro["product_id"]."'>Buy Now</a>
								                     </button>								 
			                        		</div>
			                        	";
			                        }
		                    }                            
		                }
						?>
				</div>
    	</div>
	<!--first right Panel -->
				<?php
					include 'footer.php';			         
            ?>

    </div>
</body>
</html>