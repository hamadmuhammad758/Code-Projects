<!doctype html><!---->
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Shopper | Index </title>


    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/custom.css" rel="stylesheet">

    <script type="text/javascript" src="js/respond.js"></script>
</head>

<body style="background-color:#ddd;">


	<script src="http://code.jquery.com/jquery-latest.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    
    <!--Containner div-->
    <div class="containner" style="margin:auto;">



			<?php
					include 'main_Menu.php';
					$username=$_POST['username'];
					$password=$_POST['password'];
					$email=$_POST['email'];
					$shopname=$_POST['shopname'];
					$description=$_POST['description'];
					$role='ret';
					
					$target_dir = "uploads/".$username;
					$target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);
					$uploadOk = 1;
					$uploadComplete=0;

					$imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);
					// Check if image file is a actual image or fake image
					if(isset($_POST["submit"])) {
					    $check = getimagesize($_FILES["fileToUpload"]["tmp_name"]);
					    if($check !== false) {
					        echo "File is an image - " . $check["mime"] . ".";
					        $uploadOk = 1;
					    }
					}
					// Allow certain file formats
					if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
					&& $imageFileType != "gif" ) {
					    echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
					    $uploadOk = 0;
					}
					// Check if $uploadOk is set to 0 by an error
					if ($uploadOk == 0) {
					    echo "Sorry, your file was not uploaded.";
					    
					// if everything is ok, try to upload file
					} else {
					    if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) {
					        echo "The file ". basename( $_FILES["fileToUpload"]["name"]). " has been uploaded.";
					        $uploadComplete=1;
					    } else {
					        echo "Sorry, there was an error uploading your file.";
					    }
					}

					$connection = new mysqli("localhost", "root","","shopper");
					
					if ($connection->connect_error) 
						die("Connection failed with database");
					//echo "<h1 style='text-align:center;'>Database connected successfully<br></h1>";
					
					$selectUsernameQuery="SELECT * FROM retailer WHERE username='$username'";
					$selectEmailQuery="SELECT * FROM retailer WHERE email='$email'";

					if(!(filter_var(filter_var($email, FILTER_SANITIZE_EMAIL),FILTER_VALIDATE_EMAIL) ))
					{

						echo "<h1 style='text-align:center;color:red;'>Oooops , Somthing went wrong </h1>";
						echo "<h3 style='text-align:center;'>Invalid Email Address</h3>";
						header('Location:login_signup_page.php?error=1');
						
					}else if($uploadComplete==0){						
						echo "<h1 style='text-align:center;color:red;'>Oooops , Somthing went wrong </h1>";
						echo "<h3 style='text-align:center;'>Error Uploading Image</h3>";
						header('Location:login_signup_page.php?error=2');
					}
					else if(mysqli_num_rows(mysqli_query($connection,$selectUsernameQuery)) >0  ){

						echo "<h1 style='text-align:center;color:red;'>Oooops , Somthing went wrong </h1>";
						echo "<h3 style='text-align:center;'>Username Already Exists</h3>";
						header('Location:login_signup_page.php?error=3');
					}else if(mysqli_num_rows(mysqli_query($connection,$selectEmailQuery)) >0  ){

						echo "<h1 style='text-align:center;color:red;'>Oooops , Somthing went wrong </h1>";
						echo "<h3 style='text-align:center;'>Email Already Exists</h3>";
						header('Location:login_signup_page.php?error=4');
					}
					else
					{
						//valid email
						$insertQuery="INSERT INTO retailer(username,password,email,shop_name,shop_description,role,shop_cover_image_path)
								VALUES('$username','$password','$email','$shopname','$description','$role','$target_file')";

						if(mysqli_query($connection,$insertQuery))
						{
							echo "<h1 style='text-align:center;color:red;'>Congratulations , Your shop has been cretaed.</h1>";
							header('Location:login_signup_page.php?error=5');
						}else
						{
							echo "<h1 style='text-align:center;color:red;'>Oooops , Somthing went wrong <br>
									Try Again
									</h1>";
                        	header('Location:login_signup_page.php?error=6');
						}
					}
				//	$connection->close;
			?>

    </div> <!-- Containner Div -->
 </body>
 </html>
