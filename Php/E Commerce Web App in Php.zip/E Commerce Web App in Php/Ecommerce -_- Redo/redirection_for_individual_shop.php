<?php
	//It will find retailer id on the basis of  productId
	include 'open_connection_with_db.php';
	
	$pro_id=$_GET['p_id'];

	$q="SELECT * FROM category,subcategory,product
		WHERE category.cat_id=subcategory.cat_id AND 
		subcategory.subcat_id=product.subcat_id AND
		product.product_id='$pro_id'
		";
	$res=mysqli_query($connection,$q);
	if(mysqli_num_rows($res)){
		echo "Result Found";
		while($re=mysqli_fetch_assoc($res)){
			$retail=$re["retailer_id"];
		}
	}
	header('location:individualShop.php?retailer='.$retail.'&product='.$pro_id.'');
?>