<?php

                include 'open_connection_with_db.php';
                
                $q = $_GET['q'];
                $ret_id=$_GET['ret_id'];

                $selecSubcat="SELECT subcategory.name from subcategory ,category WHERE category.name='$q' 
                AND subcategory.cat_id=category.cat_id AND category.retailer_id='$ret_id'";

                 $r=mysqli_query($connection,$selecSubcat);

                 $returning_value="";

                if (mysqli_num_rows($r) > 0) {
                    while($ro = mysqli_fetch_assoc($r)) {
                        $returning_value=$returning_value."<option>".$ro["name"]."</option>";
                    }
                }
                 echo "".$returning_value;
?>