<!doctype html><!---->
<html>
<head>
    <?php
        include'open_connection_with_db.php';
        $ret_id=$_GET["retailer"];
        $product_id=$_GET["product"];
        $shopdata="SELECT * FROM retailer where retailer_id='$ret_id'";
        $res=mysqli_query($connection,$shopdata);
        if(mysqli_num_rows($res)>0){
            while($r=mysqli_fetch_assoc($res)){
                    $shopCover=$r["shop_cover_image_path"];
                    $shopDesc=$r["shop_description"]; 
                    $shopName=$r["shop_name"];        
            }
        }
        
        $product_details="SELECT * FROM product WHERE product_id='$product_id'";
        $pp=mysqli_query($connection,$product_details);

        if(mysqli_num_rows($pp)>0){
            while($product_details=mysqli_fetch_assoc($pp)){
                $prod_name=$product_details["name"];
                $prod_price=$product_details["price"];
                $prod_description=$product_details["description"];
                $prod_image=$product_details["image"];
                $prod_stock=$product_details["stock"];
                $prod_unit=$product_details["unit"];
            }
        }
        
    ?>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Shopper | In</title>

    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/custom.css" rel="stylesheet">

    <script type="text/javascript" src="js/respond.js"></script>
    
    <script type="text/javascript">
            function saveComment(){
                var n=document.getElementById("txt_Name").value;
                var c=document.getElementById("txt_Comment").value;
                
                if (window.XMLHttpRequest) {
                    // code for IE7+, Firefox, Chrome, Opera, Safari
                    xmlhttp = new XMLHttpRequest();
                } else {
                    // code for IE6, IE5
                    xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
                }
                xmlhttp.onreadystatechange = function() {
                    if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
                        document.getElementById("txt_Name").value=xmlhttp.responseText;
                        getComments();
                    }
                };
                var pro=<?php echo ''.$product_id;?>;
                xmlhttp.open("GET","save_comments.php?names="+n+"&comments="+c+"&prod="+pro,true);
                xmlhttp.send();
            }
            function getComments(){
                 if (window.XMLHttpRequest) {
                    // code for IE7+, Firefox, Chrome, Opera, Safari
                    xmlhttp = new XMLHttpRequest();
                } else {
                    // code for IE6, IE5
                    xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
                }
                xmlhttp.onreadystatechange = function() {
                    if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
                        document.getElementById("oldComments").innerHTML=xmlhttp.responseText;
                    }
                };
                var pro=<?php echo ''.$product_id;?>;
                xmlhttp.open("GET","getAllComments.php?prod="+pro,true);
                xmlhttp.send();
            }

            function addtoCartt(){
                var pro=<?php echo ''.$product_id;?>;
                document.getElementById("cartImage").src="uploads/animate.gif";
                 if (window.XMLHttpRequest) {
                    // code for IE7+, Firefox, Chrome, Opera, Safari
                    xmlhttp = new XMLHttpRequest();
                } else {
                    // code for IE6, IE5
                    xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
                }
                xmlhttp.onreadystatechange = function() {
                    if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
                       document.getElementById("cartImage").src="uploads/carts.png";
                    }
                };

                xmlhttp.open("GET","addToCart.php?prod="+pro,true);
                xmlhttp.send();
            }

    </script>
</head>

<body style="background-color:black;" onload="getComments()">


	<script src="http://code.jquery.com/jquery-latest.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    
    <!--Containner div-->
    <div class="containner" style="margin:auto;">
			<?php
					include 'main_Menu.php';		         
            ?>
          <div  style="opacity:;margin-top:-23px;margin-bottom:0px;background:url('<?php echo "".$shopCover; ?>') no-repeat center center;background-size: 100% 100%;height:35em;" >    
                    <h1 style="background-color:#222222;text-align:center;color:white;opacity:1; "><?php echo "".$shopName."<br>".$shopDesc; ?></h1>                  
          </div>
          <?php
                include 'menu_individual_shop.php';
          ?>
          <div class="row" style="min-height:300px;margin-top:0px;">
          
            <div class="panel panel-success col col-sm-8" style="background-color:white;min-height:300px;margin-left:30px;margin-bottom:20px;">
                    <h1 class="panel panel-heading">Product Details</h1>
                    <div class="panel panel-body">
                        <div class="row">
                            <div class="col col-sm-5">
                                <img src="<?php echo ''.$prod_image ?>" style="width:300px;height:300px;" />
                            </div>
                            <div class="col col-sm-5">
                                <h1><?php echo ''.$prod_name;?></h1>
                                <p><?php echo ''.$prod_description;?></p>
                           </div>
                        </div>

                        <div class="row">
                            <div class="col col-sm-5">
                                <h1 style="text-align:center;"><?php echo ''.$prod_price.' '.$prod_unit;?></h1>
                            </div>
                            <div class="col col-sm-5">
                                <h3 class="bg-danger" style="display:inline-block;text-align:center;"><?php echo ''.$prod_stock.' Items Left...';?></h3>
                                <a onclick="addtoCartt()"><img style="display:inline-block;width:50px;height:50px;" src="uploads/carts.png" id="cartImage"/></a>
                           </div>
                        </div>
                        <div class="row">
                            <div class="panel panel-danger col col-sm-10 col-sm-offset-1">
                                <div class="panel panel-heading">
                                    <h2>Customer reviews</h2>
                                </div>
                                <div class="panel panel-body">
                                     <div id="oldComments">
                                     </div>   
                                    <div class="form-group panel panel-footer" style="margin-top:20px;">
                                        <h2>Share your thoughts</h2>
                                        <form method="post">                                                
                                          <div class="form-group">
                                            <input type="text" class="form-control"  name="name_yourName"  required id="txt_Name"  value="" placeholder="Your name">
                                          </div>                                            
                                          <div class="form-group">
                                            <input type="text" class="form-control"  name="name_yourComment"  required id="txt_Comment"  value="" placeholder="Your Comment">
                                          </div>
                                            <button type="button" name="submit" onclick="saveComment()" class="btn btn-default">Post</button>    
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
            </div>

            <div class="col col-sm-3" style="background-color:white;min-height:300px;margin-left:20px;">
            </div>
          
          </div>

          <?php
            include'footer.php';
          ?>
    </div>
</body>
</html>
